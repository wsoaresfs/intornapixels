const KEY='intorna_flow_bridge_queue_v22';
async function getQueue(){const x=await chrome.storage.local.get(KEY);return Array.isArray(x[KEY])?x[KEY]:[]}
async function setQueue(q){await chrome.storage.local.set({[KEY]:q});await chrome.action.setBadgeText({text:q.length?String(Math.min(q.length,99)):''});return q}
function same(a,b){return String(a?.jobId||'')===String(b?.jobId||'')&&String(a?.stage||'')===String(b?.stage||'')&&String(a?.target||'')===String(b?.target||'')}
chrome.runtime.onInstalled.addListener(()=>setQueue([]));
chrome.runtime.onMessage.addListener((msg,sender,send)=>{
 (async()=>{
  const action=String(msg?.action||'');
  if(action==='push'){let q=await getQueue();const p=msg.pack||{};q=q.filter(x=>!same(x,p));q.push(p);await setQueue(q);send({ok:true,count:q.length});return}
  if(action==='status'){const q=await getQueue();send({ok:true,count:q.length,queue:q});return}
  if(action==='current'){const q=await getQueue();send({ok:true,count:q.length,current:q[0]||null});return}
  if(action==='done'){let q=await getQueue();if(msg.jobId)q=q.filter(x=>!(String(x.jobId)===String(msg.jobId)&&(!msg.stage||String(x.stage)===String(msg.stage))));else q.shift();await setQueue(q);send({ok:true,count:q.length,current:q[0]||null});return}
  if(action==='clear'){await setQueue([]);send({ok:true,count:0});return}
  if(action==='open_current'){const q=await getQueue(),p=q[0];if(!p?.providerUrl){send({ok:false,error:'Fila vazia'});return}await chrome.tabs.create({url:p.providerUrl});send({ok:true});return}
  send({ok:false,error:'Ação desconhecida'});
 })().catch(e=>send({ok:false,error:String(e?.message||e)}));return true;
});

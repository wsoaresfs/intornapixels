window.addEventListener('message',event=>{
 if(event.source!==window)return;
 const d=event.data||{};
 if(d.type==='INTORNA_FLOW_BRIDGE_PING'){
  chrome.runtime.sendMessage({action:'status'},r=>window.postMessage({type:'INTORNA_FLOW_BRIDGE_PONG',count:r?.count||0},'*'));
 }
 if(d.type==='INTORNA_FLOW_BRIDGE_STATUS'){
  chrome.runtime.sendMessage({action:'status'},r=>window.postMessage({type:'INTORNA_FLOW_BRIDGE_QUEUE_STATUS',count:r?.count||0},'*'));
 }
 if(d.type==='INTORNA_FLOW_BRIDGE_PUSH'&&d.payload){
  chrome.runtime.sendMessage({action:'push',pack:d.payload},r=>window.postMessage({type:'INTORNA_FLOW_BRIDGE_QUEUE_STATUS',count:r?.count||0},'*'));
 }
});

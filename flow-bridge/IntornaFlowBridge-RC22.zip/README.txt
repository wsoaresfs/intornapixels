INTORNÁ FLOW BRIDGE RC22

Instalação no Chrome/Edge:
1. Extraia este ZIP para uma pasta.
2. Abra chrome://extensions ou edge://extensions.
3. Ative "Modo do desenvolvedor".
4. Clique em "Carregar sem compactação".
5. Selecione a pasta extraída.
6. Atualize a página do Intorná Pixels.

A RC22 separa cada item em três etapas: candidato de referência, foto-teste e lote liberado.
A extensão não guarda senhas ou chaves. Ela gerencia a fila, mantém um cliente por contexto,
avisa quando os links expiram, abre as referências e ajuda a avançar para o próximo job.
